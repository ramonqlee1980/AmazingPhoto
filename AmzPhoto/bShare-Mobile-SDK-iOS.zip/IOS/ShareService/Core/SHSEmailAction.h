//
//  SHSEmailAction.h
//  ShareDemo
//
//  Created by mini2 on 29/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MessageUI/MessageUI.h>
#import "SHSAction.h"

@interface SHSEmailAction : NSObject<SHSActionProtocol,MFMailComposeViewControllerDelegate>

@end
