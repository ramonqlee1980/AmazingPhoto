//
//  SHSAPIKeys.h
//  ShareDemo
//
//  Created by tmy on 11-11-23.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//


//腾讯微博
#define TXWEIBO_APP_KEY @"654f906e588947bdb1ef86865d6fc425"
#define TXWEIBO_SECRET_KEY @"67aa9059bb904064aa9df365032f703f"

//新浪微博
#define SINAWEIBO_APP_KEY @"3002548984"
#define SINAWEIBO_SECRET_KEY @"3bbcc9e9e5027873bc2f597090cd2d9d"


//搜狐微博
#define SOHUWEIBO_APP_KEY @"NMfywJkfVF0yPYAmbA8D"
#define SOHUWEIBO_SECRET_KEY @"aKKkZQ00q1TVM#mC$MtmDVsJkbd#E5tYcWHBb*hn"


//开心网
#define KAIXIN_APP_KEY @"842605380987347bb8764440079df078"
#define KAIXIN_SECRET_KEY @"611020569a506f79566f057f8dd22d12"

//人人网
#define RENREN_APP_KEY @"3111b4745daf43cf994cd0761090f54d"
#define RENREN_SECRET_KEY @"b8e1e86302b24bec9a4c6829206a4145"

//publisherUuid
#define PUBLISHER_UUID @""
