//
//  DataStatistic.h
//  ShareDemo
//
//  Created by Buzzinate Buzzinate on 12-2-28.
//  Copyright (c) 2012年 Buzzinate Co. Ltd. All rights reserved.
//

#ifndef ShareDemo_DataStatistic_h
#define ShareDemo_DataStatistic_h
@interface DataStatistic:NSObject
- (void)sendStatistic:(NSString *)url site:(NSString*)site;
@end
#endif
